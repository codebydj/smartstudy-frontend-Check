import React from "react";

export default function Register() {
  return <h1>Register Page will upadate soon</h1>;
}
