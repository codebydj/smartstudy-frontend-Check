import React from "react";

export default function LatestNotes() {
  return <h1>Latest Notes Page  will upadate soon</h1>;
}
